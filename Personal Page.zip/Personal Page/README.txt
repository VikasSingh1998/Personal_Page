Personal page: Sumedh Kamble
This personal page has following sections with its description:
Home section describes aspects of my professional life, goals, expectation, skills, overall experience.
Next section is of  Education which list all the academics and CGPAs.
Next section is of Work experience which describes all the organization i worked for , projects i worked on and my contribution in it ,along with some other important information related to work.
Next section is of Projects which contains the information regarding personal projects and its description.
Next section is of Skills which i am comfortable with to work on.
Next section is of Contact through which you can get contact me. It has all the links for LinkedIn, Github,etc.

Technologies: HTML, CSS, Javascript.

Files:
index.html : Main file which has all the HTML code.
style.css: It has all the CSS styles used in html.
script.js: It has all the javascript code used in pages.
photo.jpg: Profile picture


I have hosted my page in GITHUB.io. You can acess it from URL: https://k-sumedh.github.io/knowMe/